"use strict"
let veces =5 ;
let numero=2 ;
function repetirYDuplicar(veces, numero){
    for (let i= 0; i< veces; i++){
        
        
        console.log(numero);
        numero= numero*2;
    }
}
repetirYDuplicar( veces, numero);
