"use strict";
window.onload = ()=>{
 
var d=document;

var minutos=0;
var segundos=0;
var imgAnterior="";
var aciertos=0;
var jugar=true;
var numero= d.getElementById("intentos").value=0;
function crearComunicacionUsuario(){//Este método lo usaremos siempre para comunicarnos con el usuario.
  var mostrar = d.createElement("div");
        mostrar.innerHTML="<p id='mensajeAlUsuario' class='hidden'> </p>"
 d.body.appendChild(mostrar);
 }
 crearComunicacionUsuario();
 function sumarIntento(){
     numero= d.getElementById("intentos");//Método para sumar intentos.
        numero.value= parseInt(numero.value)+1;
   
 }
 setInterval(() => {//Método para el temporizador.
  tiempo= d.getElementById("tiempo"); 
 if(aciertos!=6){
    if(segundos==59){
      segundos=0;
      minutos++;
    }
    else{
      segundos++;
    }
    tiempo.innerHTML=`El tiempo que llevas jugando es ${minutos} minutos y ${segundos} segundos; `; }
    else{
      tiempo.innerHTML=`El tiempo que has para necesitado para completar el juego es ${minutos} minutos y ${segundos} segundos; `; }
    
 }, 1000);
var img=["img/astrology.jpg","img/snes.png", "img/drink.jpg", "img/beach.jpg","img/cliff.jpg","img/windmills.jpg","img/astrology.jpg","img/snes.png", "img/drink.jpg", "img/beach.jpg","img/cliff.jpg","img/windmills.jpg","" ];
 
for(let i=0; i<12; i++ ){//Para poner el número aleatorio.
  let nAleatorio=Math.round(Math.random()*11);
  img[12]= img[i];
  img[i]=img[nAleatorio];
  img[nAleatorio]= img[12];}
  for(let i=0; i<12; i++ ){
    d.getElementsByClassName("rTableCell")[i].addEventListener("click",(event)=>{
      
      //La última comprobación se hace para que si pincha fuera de la imagen no funcione. Ya que hemos maquetado con div que ocupan más espacios que la propia imagen. Y todas las img tienen el mismo width.
if(aciertos!=6 && jugar && event.target.width=="135"){//Así solo se puede jugar si el semáforo deja pasar y no se ha llegado al límte de aciertos así evitamos los problemas con el click mientras se muestra el error pues no hace nada hasta que no acabe la animación.

   event.target.setAttribute("src", img[i]);
      if(imgAnterior==""){
        imgAnterior= event.target;
       
      }
      else if(imgAnterior.name=== event.target.name){//Aquí comprobamos es que la misma carta. 
        let mensajeError= d.getElementById("mensajeAlUsuario");
        mensajeError.classList.remove("hidden");
        mensajeError.innerHTML="Estás pulsado en la misma carta <em>idiota</em> !!";
 setTimeout(()=>{      
   mensajeError.className="hidden";
}, 1000)
      }
      else if(imgAnterior.src== event.target.src){ //Si tienen la misma imagen.
        let mensajeError= d.getElementById("mensajeAlUsuario");
               mensajeError.classList.remove("hidden");
               mensajeError.innerText="¡Has acertado!";
               aciertos++;
        setTimeout(()=>{      
          mensajeError.className="hidden";
    }, 1000)
        imgAnterior="";

      }  
      else{
        let mensajeError= d.getElementById("mensajeAlUsuario");//Si no es la misma carta la mostramos durante un segundo para que el usuario pueda verla
               mensajeError.classList.remove("hidden");
               mensajeError.innerText=" ¡Esta vez no has conseguido pareja!";
               jugar=false;
              sumarIntento();
        setTimeout(()=>{//Así dejamos el error durante un tiempo deternminado.
          imgAnterior.src="img/baraja.jpg"
          event.target.src="img/baraja.jpg";
          jugar=true;
          imgAnterior="";
          mensajeError.className="hidden";
          
    }, 1000)
  } 
  if(aciertos==6){//Una vez acertamos todo mostramos el mensaje de la victoria!!!
   let p= d.createElement("p");
  p.innerText=` Te has pasado el juego puedes comprobar los intentos y el tiempo que has tardado en la parte de arriba.`;
  p.id="ganador";
  d.body.appendChild(p); 
   }
}
    },false);
  }       

}
