import {consulta} from "./imports/starWarsAPI.js";
"use strict";
 window.onload= ()=>{
//Consultamos los datos de las películas.
consulta();

} 